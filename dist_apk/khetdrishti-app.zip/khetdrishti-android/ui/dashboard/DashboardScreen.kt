package com.khetdrishti.app.ui.dashboard

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.khetdrishti.app.ui.components.*
import com.khetdrishti.app.ui.theme.*

/**
 * Main KhetDrishti Responsive Dashboard
 * SaaS Aesthetic: Space-Slate Dark (#0B132B) + Crisp Agricultural Emerald (#10B981)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel = hiltViewModel(),
    onNavigateToModule: (moduleIndex: Int) -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        containerColor = SpaceSlateDark,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(RoundedCornerShape(50))
                                .background(AgroEmerald)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "KhetDrishti",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "(A.S atif)",
                            fontSize = 12.sp,
                            color = AgroEmerald,
                            fontWeight = FontWeight.Medium
                        )
                    }
                },
                actions = {
                    // Audio Sonification Quick Toggle
                    IconButton(onClick = { viewModel.toggleSonification() }) {
                        Icon(
                            imageVector = if (uiState.isSonifying) Icons.Default.VolumeUp else Icons.Default.SpatialAudioOff,
                            contentDescription = "Sonify Field Data",
                            tint = if (uiState.isSonifying) AgroEmerald else SlateMuted
                        )
                    }
                    IconButton(onClick = { viewModel.refreshLocationAndNasaData() }) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Sync NASA Telemetry",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SpaceSlateDark
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. GPS Auto-Location & Weather Engine Header
            item {
                WeatherHeaderCard(
                    locationName = uiState.currentLocationName,
                    coordinates = uiState.coordinates,
                    forecastList = uiState.sevenDayForecast,
                    bestTimeWindow = uiState.bestFarmingWindow,
                    isLoading = uiState.isWeatherLoading
                )
            }

            // 2. Active Fire Hotspots Banner (NASA VIIRS/MODIS)
            if (uiState.fireAlert.isDetected) {
                item {
                    FireHotspotAlertCard(
                        fireAlert = uiState.fireAlert,
                        onDismiss = { viewModel.dismissFireAlert() }
                    )
                }
            }

            // 3. Audio Sonification Accessibility Bar
            item {
                SonificationControlCard(
                    isSonifying = uiState.isSonifying,
                    selectedLanguage = uiState.sonificationLanguage,
                    onToggleSonify = { viewModel.toggleSonification() },
                    onLanguageSelect = { lang -> viewModel.setSonificationLanguage(lang) }
                )
            }

            // 4. Core Field Health Bento Grid (SMAP, ECOSTRESS, GPM, NISAR)
            item {
                Text(
                    text = "FIELD TELEMETRY · BENTO INTELLIGENCE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    color = SlateMuted
                )
            }

            item {
                FieldHealthBentoGrid(
                    telemetry = uiState.telemetry,
                    onCardClick = { metricKey -> onNavigateToModule(1) }
                )
            }

            // 5. Seven Core Agri-Modules Quick Nav
            item {
                Text(
                    text = "THE 7 AGRI-MODULES",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp,
                    color = SlateMuted
                )
            }

            item {
                AgriModulesCarousel(
                    activePlot = uiState.activePlot,
                    earlyWarningCount = uiState.earlyWarnings.size,
                    onSelectModule = onNavigateToModule
                )
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}