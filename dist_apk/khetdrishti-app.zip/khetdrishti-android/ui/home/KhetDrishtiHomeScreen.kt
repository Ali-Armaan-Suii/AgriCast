package com.khetdrishti.app.ui.home

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.khetdrishti.app.ui.components.KhetDrishtiStatusPill
import com.khetdrishti.app.ui.theme.*

/**
 * KhetDrishtiHomeScreen (A.S atif)
 * 1. Top Animated Hero Section (Header) with landscape vector & status pill
 * 2. Overlapping Services Grid (Main 8 Features in 4 columns)
 * 3. Middle Interactive NASA Alert Coupon Banner
 * 4. Quick Features / Recommendation Pastel Cards (Horizontal LazyRow)
 * 5. Fixed Bottom Navigation Bar with Center Scanner FAB
 */
@Composable
fun KhetDrishtiHomeScreen(
    farmerName: String = "A.S Atif",
    onNavigateToModule: (String) -> Unit = {},
    onScanClick: () -> Unit = {},
    onSearchClick: () -> Unit = {}
) {
    var selectedBottomNav by remember { mutableStateOf(0) }

    Scaffold(
        bottomBar = {
            KhetDrishtiBottomNavigation(
                selectedItem = selectedBottomNav,
                onItemSelected = { selectedBottomNav = it },
                onScanClick = onScanClick
            )
        },
        containerColor = CanvasBackground
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. TOP ANIMATED HERO SECTION (Header)
            item {
                AgroAnimatedHeroHeader(
                    farmerName = farmerName,
                    onSearchClick = onSearchClick
                )
            }

            // 2. OVERLAPPING SERVICES GRID (8 Core Features)
            item {
                OverlappingAgroServicesGrid(
                    onModuleClick = onNavigateToModule
                )
            }

            // 3. MIDDLE INTERACTIVE CAROUSEL / ALERT BANNER
            item {
                AgroPromotionalAlertBanner(
                    onBannerClick = { onNavigateToModule("alert_rain") }
                )
            }

            // 4. QUICK FEATURES / SUGGESTION CARDS (Horizontal Scroll)
            item {
                AgroRecommendationCardsRow(
                    onCardClick = onNavigateToModule
                )
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

/**
 * 1. Top Animated Hero Section (Header)
 * Deep pink background with animated landscape vectors, hills, sky, moving clouds & floating satellite
 */
@Composable
fun AgroAnimatedHeroHeader(
    farmerName: String,
    onSearchClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "hero_anim")
    val cloudOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 600f,
        animationSpec = infiniteRepeatable(
            animation = tween(18000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "clouds"
    )
    val floatY by infiniteTransition.animateFloat(
        initialValue = -3f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "satellite_float"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(KhetPinkPrimary, KhetPinkDark)
                )
            )
            .padding(top = 18.dp, bottom = 42.dp, start = 16.dp, end = 16.dp)
    ) {
        // Continuous moving clouds & hill contours canvas
        Canvas(modifier = Modifier.matchParentSize()) {
            val canvasWidth = size.width
            val xPos = (cloudOffset % (canvasWidth + 200f)) - 100f

            // Orbit arc
            drawArc(
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, SurfaceWhite.copy(alpha = 0.35f), Color.Transparent)
                ),
                startAngle = 180f,
                sweepAngle = 180f,
                useCenter = false,
                topLeft = Offset(-80f, 30f),
                size = androidx.compose.ui.geometry.Size(canvasWidth + 160f, 160f)
            )

            // Landscape Hill 1
            val hillPath1 = Path().apply {
                moveTo(0f, 290f)
                cubicTo(canvasWidth * 0.3f, 250f, canvasWidth * 0.7f, 310f, canvasWidth, 270f)
                lineTo(canvasWidth, 400f)
                lineTo(0f, 400f)
                close()
            }
            drawPath(path = hillPath1, color = Color(0x2E64052E))

            // Drifting Cloud Silhouette
            val cloudPath = Path().apply {
                moveTo(xPos, 65f)
                cubicTo(xPos + 30f, 40f, xPos + 70f, 50f, xPos + 90f, 65f)
                cubicTo(xPos + 120f, 55f, xPos + 150f, 75f, xPos + 140f, 95f)
                lineTo(xPos, 95f)
                close()
            }
            drawPath(path = cloudPath, color = SurfaceWhite.copy(alpha = 0.15f))
        }

        Column(modifier = Modifier.fillMaxWidth()) {
            // Header Top Row: Profile (Left) & Search + Origami Satellite (Right)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Farmer profile avatar with name
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(SurfaceWhite)
                            .padding(2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .background(KhetPinkDark),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = SurfaceWhite,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = farmerName,
                                color = SurfaceWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(SurfaceWhite.copy(alpha = 0.2f))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "কৃষি বিজ্ঞানী",
                                    color = SurfaceWhite,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Text(
                            text = "লুধিয়ানা এগ্রো সেক্টর",
                            color = KhetPinkTint,
                            fontSize = 11.sp
                        )
                    }
                }

                // Top-Right: Search icon and floating origami satellite logo
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IconButton(
                        onClick = onSearchClick,
                        modifier = Modifier
                            .size(36.dp)
                            .background(SurfaceWhite.copy(alpha = 0.15f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = SurfaceWhite,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Floating Origami Satellite
                    Box(
                        modifier = Modifier
                            .offset(y = floatY.dp)
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(SurfaceWhite.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SatelliteAlt,
                            contentDescription = "Origami Satellite",
                            tint = SurfaceWhite,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Center Pill Button: "জমির অবস্থা দেখুন"
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                KhetDrishtiStatusPill(
                    moisturePercent = 24,
                    isSafe = true
                )
            }
        }
    }
}

/**
 * 2. Overlapping Services Grid (Main Features)
 * Pure white card elevated over the pink header with 8 circular items
 */
data class AgroGridService(
    val id: String,
    val title: String,
    val icon: ImageVector,
    val badge: String? = null
)

@Composable
fun OverlappingAgroServicesGrid(
    onModuleClick: (String) -> Unit
) {
    val services = remember {
        listOf(
            // Row 1
            AgroGridService("my_field", "আমার জমি", Icons.Default.Grass),
            AgroGridService("field_health", "জমির স্বাস্থ্য", Icons.Default.Analytics),
            AgroGridService("timeline", "টাইমলাইন", Icons.Default.Timeline),
            AgroGridService("early_warning", "সতর্কবার্তা", Icons.Default.WarningAmber, badge = "জরুরি"),
            // Row 2
            AgroGridService("what_if", "সিমুলেশন", Icons.Default.Tune),
            AgroGridService("nisar", "নিসার রাডার", Icons.Default.Radar),
            AgroGridService("fire", "আগুন সতর্কতা", Icons.Default.LocalFireDepartment, badge = "হটস্পট"),
            AgroGridService("audio_guide", "অডিও পরামর্শ", Icons.Default.Headphones)
        )
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .offset(y = (-24).dp)
            .padding(horizontal = 14.dp)
            .shadow(10.dp, RoundedCornerShape(24.dp))
            .clip(RoundedCornerShape(24.dp))
            .background(SurfaceWhite)
            .padding(vertical = 18.dp, horizontal = 12.dp)
    ) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.height(180.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            userScrollEnabled = false
        ) {
            items(services) { item ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onModuleClick(item.id) }
                ) {
                    Box(contentAlignment = Alignment.TopEnd) {
                        // Circular Pink-tinted icon container (#FDE8F1 with #E2136E icon)
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(KhetPinkTint),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.title,
                                tint = KhetPinkPrimary,
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        item.badge?.let { badgeText ->
                            Box(
                                modifier = Modifier
                                    .offset(x = 4.dp, y = (-4).dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(KhetPinkPrimary)
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = badgeText,
                                    color = SurfaceWhite,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = item.title,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

/**
 * 3. Middle Interactive Promotional NASA Alert Banner
 */
@Composable
fun AgroPromotionalAlertBanner(
    onBannerClick: () -> Unit
) {
    Card(
        onClick = onBannerClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = KhetPinkTint),
        border = androidx.compose.foundation.BorderStroke(1.dp, KhetPinkPrimary.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(KhetPinkPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CloudSync,
                        contentDescription = null,
                        tint = SurfaceWhite,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(KhetPinkPrimary)
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "সরাসরি সতর্কতা",
                                color = SurfaceWhite,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "NASA GPM IMERG",
                            fontSize = 10.sp,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    Text(
                        text = "⚠️ আগামী ৪৮ ঘণ্টায় ভারী বৃষ্টির সম্ভাবনা - নিষ্কাশন নালা পরিষ্কার রাখুন",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        lineHeight = 16.sp
                    )
                }
            }

            Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = null,
                tint = KhetPinkPrimary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

/**
 * 4. Quick Features / Recommendation Cards (LazyRow Horizontal Scroll)
 */
data class AgroRecommendation(
    val id: String,
    val category: String,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val bg: Color,
    val border: Color,
    val accent: Color
)

@Composable
fun AgroRecommendationCardsRow(
    onCardClick: (String) -> Unit
) {
    val items = remember {
        listOf(
            AgroRecommendation(
                id = "moisture_deficit",
                category = "আর্দ্রতা ঘাটতি",
                title = "মাটির আর্দ্রতা ঘাটতি",
                description = "মাটির উপরের স্তরে পানির পরিমাণ ১৮% এর নিচে নেমেছে। ড্রিপ সেচ বিবেচনা করুন।",
                icon = Icons.Default.WaterDrop,
                bg = PastelAmber,
                border = PastelAmberBorder,
                accent = PastelAmberText
            ),
            AgroRecommendation(
                id = "irrigation_time",
                category = "সেচ শিডিউল",
                title = "সেচ দেওয়ার মোক্ষম সময়",
                description = "আজ সূর্যাস্তের পর ১৮ মিমি ড্রিপ সেচ দিন যাতে বাষ্পীভবনে অপচয় না হয়।",
                icon = Icons.Default.Schedule,
                bg = PastelGreen,
                border = PastelGreenBorder,
                accent = PastelGreenText
            ),
            AgroRecommendation(
                id = "fertilizer_day",
                category = "পুষ্টি প্রয়োগ",
                title = "সার প্রয়োগের উপযুক্ত দিন",
                description = "আগামী ৩ দিন অনুকূল তাপমাত্রা ও কম বাতাস থাকবে। পটাশ স্প্রে করুন।",
                icon = Icons.Default.WbSunny,
                bg = PastelBlue,
                border = PastelBlueBorder,
                accent = PastelBlueText
            )
        )
    }

    Column(modifier = Modifier.padding(horizontal = 14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "জরুরি পরামর্শসমূহ",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "সব দেখুন →",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = KhetPinkPrimary
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(items) { card ->
                Card(
                    modifier = Modifier
                        .width(260.dp)
                        .height(140.dp)
                        .clickable { onCardClick(card.id) },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = card.bg),
                    border = androidx.compose.foundation.BorderStroke(1.dp, card.border),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = card.category,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = card.accent
                            )
                            Icon(
                                imageVector = card.icon,
                                contentDescription = null,
                                tint = card.accent,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Column {
                            Text(
                                text = card.title,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = card.description,
                                fontSize = 11.sp,
                                color = TextMuted,
                                maxLines = 2,
                                lineHeight = 15.sp
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "পরামর্শ দেখুন",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = card.accent
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = null,
                                tint = card.accent,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * 5. Fixed Bottom Navigation Bar
 * 4 items: হোম, আমার জমি, কিউআর/স্ক্যান (center button), ইনবক্স
 */
@Composable
fun KhetDrishtiBottomNavigation(
    selectedItem: Int,
    onItemSelected: (Int) -> Unit,
    onScanClick: () -> Unit
) {
    Box(modifier = Modifier.fillMaxWidth().height(78.dp)) {
        NavigationBar(
            containerColor = SurfaceWhite,
            tonalElevation = 8.dp,
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(64.dp)
        ) {
            NavigationBarItem(
                selected = selectedItem == 0,
                onClick = { onItemSelected(0) },
                icon = { Icon(Icons.Default.Home, contentDescription = "হোম") },
                label = { Text("হোম", fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = KhetPinkPrimary,
                    selectedTextColor = KhetPinkPrimary,
                    indicatorColor = KhetPinkTint
                )
            )

            NavigationBarItem(
                selected = selectedItem == 1,
                onClick = { onItemSelected(1) },
                icon = { Icon(Icons.Default.Park, contentDescription = "আমার জমি") },
                label = { Text("আমার জমি", fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = KhetPinkPrimary,
                    selectedTextColor = KhetPinkPrimary,
                    indicatorColor = KhetPinkTint
                )
            )

            Spacer(modifier = Modifier.weight(1f))

            NavigationBarItem(
                selected = selectedItem == 2,
                onClick = { onItemSelected(2) },
                icon = { Icon(Icons.Default.Explore, contentDescription = "রাডার") },
                label = { Text("রাডার", fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = KhetPinkPrimary,
                    selectedTextColor = KhetPinkPrimary,
                    indicatorColor = KhetPinkTint
                )
            )

            NavigationBarItem(
                selected = selectedItem == 3,
                onClick = { onItemSelected(3) },
                icon = {
                    BadgedBox(badge = { Badge(containerColor = AlertRed) { Text("২") } }) {
                        Icon(Icons.Default.Mail, contentDescription = "ইনবক্স")
                    }
                },
                label = { Text("ইনবক্স", fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = KhetPinkPrimary,
                    selectedTextColor = KhetPinkPrimary,
                    indicatorColor = KhetPinkTint
                )
            )
        }

        // Floating Center Scanner FAB (45-degree rotated rounded square)
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .size(56.dp)
                .rotate(45f)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.linearGradient(listOf(KhetPinkDark, KhetPinkPrimary))
                )
                .border(2.dp, SurfaceWhite, RoundedCornerShape(16.dp))
                .clickable { onScanClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.QrCodeScanner,
                contentDescription = "কিউআর/স্ক্যান",
                tint = SurfaceWhite,
                modifier = Modifier
                    .size(28.dp)
                    .rotate(-45f)
            )
        }
    }
}