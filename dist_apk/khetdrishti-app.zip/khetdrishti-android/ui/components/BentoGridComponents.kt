package com.khetdrishti.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.khetdrishti.app.domain.model.NasaTelemetry
import com.khetdrishti.app.ui.theme.*

@Composable
fun FieldHealthBentoGrid(
    telemetry: NasaTelemetry,
    onCardClick: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Row 1: SMAP (60% width) + ECOSTRESS (40% width)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // SMAP Soil Moisture
            BentoContainer(
                modifier = Modifier
                    .weight(1.3f)
                    .clickable { onCardClick("SMAP") },
                accentColor = AgroEmerald
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SOIL MOISTURE (SMAP L4)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SlateMuted
                        )
                        Icon(
                            imageVector = Icons.Default.WaterDrop,
                            contentDescription = null,
                            tint = AgroEmerald,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "\${(telemetry.smapSurfaceMoisture * 100).toInt()}%",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Root-zone: \${(telemetry.smapRootZoneMoisture * 100).toInt()}% VWC · 0-100cm",
                        fontSize = 12.sp,
                        color = if (telemetry.smapSurfaceMoisture < 0.18) AmberWarning else AgroEmerald
                    )
                }
            }

            // ECOSTRESS Canopy Temp
            BentoContainer(
                modifier = Modifier
                    .weight(1.0f)
                    .clickable { onCardClick("ECOSTRESS") },
                accentColor = if (telemetry.ecostressCanopyTempC > 32) CrimsonAlert else AgroEmerald
            ) {
                Column {
                    Text(
                        text = "CANOPY TEMP",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SlateMuted
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "\${telemetry.ecostressCanopyTempC.toInt()}°C",
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "ECOSTRESS (ISS)",
                        fontSize = 11.sp,
                        color = SlateMuted
                    )
                }
            }
        }

        // Row 2: GPM IMERG Rainfall + NISAR Subsurface Radar Coherence
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // GPM IMERG
            BentoContainer(
                modifier = Modifier
                    .weight(1.0f)
                    .clickable { onCardClick("GPM") },
                accentColor = Color(0xFF38BDF8)
            ) {
                Column {
                    Text(
                        text = "PRECIPITATION (GPM)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SlateMuted
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "\${telemetry.gpmAccumulated24hMm} mm",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Last rain: \${telemetry.gpmLastRainTimestamp}",
                        fontSize = 11.sp,
                        color = SlateMuted
                    )
                }
            }

            // NISAR Subsurface Deformation & L-Band SAR
            BentoContainer(
                modifier = Modifier
                    .weight(1.3f)
                    .clickable { onCardClick("NISAR") },
                accentColor = Color(0xFFA855F7)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "NISAR SAR COHERENCE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SlateMuted
                        )
                        Icon(
                            imageVector = Icons.Default.Radar,
                            contentDescription = null,
                            tint = Color(0xFFA855F7),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "\${(telemetry.nisarLbandCoherence * 100).toInt()}% Coherence",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Subsurface: \${telemetry.nisarSubsurfaceMoisturePct}% · Def: \${telemetry.nisarSurfaceDeformationMm}mm/yr",
                        fontSize = 11.sp,
                        color = SlateMuted
                    )
                }
            }
        }
    }
}

@Composable
fun BentoContainer(
    modifier: Modifier = Modifier,
    accentColor: Color = AgroEmerald,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(SpaceSlateCard)
            .border(1.dp, SpaceSlateBorder, RoundedCornerShape(16.dp))
            .padding(16.dp),
        content = content
    )
}