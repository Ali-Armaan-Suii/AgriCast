package com.khetdrishti.app.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.EnergySavingsLeaf
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.khetdrishti.app.ui.theme.*
import kotlinx.coroutines.delay

/**
 * KhetDrishtiStatusPill
 * Exact 1:1 replica of the balance check capsule button:
 * - White rounded pill container with circular primary-pink icon on the left
 * - Initial Label: "জমির অবস্থা দেখুন"
 * - Revealed Label: "মাটির আর্দ্রতা: ২৪% | ঝুঁকি নেই"
 * - Automatically collapses back after 4.0 seconds
 */
@Composable
fun KhetDrishtiStatusPill(
    moisturePercent: Int = 24,
    isSafe: Boolean = true,
    modifier: Modifier = Modifier
) {
    var isRevealed by remember { mutableStateOf(false) }

    // Auto-collapse after exactly 4 seconds
    LaunchedEffect(isRevealed) {
        if (isRevealed) {
            delay(4000)
            isRevealed = false
        }
    }

    Surface(
        onClick = { isRevealed = !isRevealed },
        shape = RoundedCornerShape(50),
        color = SurfaceWhite,
        shadowElevation = 8.dp,
        modifier = modifier.animateContentSize(
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioLowBouncy,
                stiffness = Spring.StiffnessMedium
            )
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            // Circular Pink Badge Icon
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(if (isRevealed) KhetPinkPrimary else KhetPinkTint),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isRevealed) Icons.Default.Check else Icons.Default.EnergySavingsLeaf,
                    contentDescription = null,
                    tint = if (isRevealed) SurfaceWhite else KhetPinkPrimary,
                    modifier = Modifier.size(14.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Animated content transition
            AnimatedContent(
                targetState = isRevealed,
                transitionSpec = {
                    (fadeIn() + expandHorizontally()) togetherWith (fadeOut() + shrinkHorizontally())
                },
                label = "status_pill_transition"
            ) { revealed ->
                if (revealed) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "মাটির আর্দ্রতা: $moisturePercent%",
                            color = KhetPinkPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = " | ",
                            color = KhetPinkDark.copy(alpha = 0.5f),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = if (isSafe) "ঝুঁকি নেই" else "সতর্কতা",
                            color = if (isSafe) Color(0xFF2E7D32) else AlertRed,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                } else {
                    Text(
                        text = "জমির অবস্থা দেখুন",
                        color = KhetPinkPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Icon(
                imageVector = if (isRevealed) Icons.Default.VisibilityOff else Icons.Default.ChevronRight,
                contentDescription = null,
                tint = KhetPinkPrimary,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}