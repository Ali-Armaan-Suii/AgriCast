package com.khetdrishti.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// 1. Signature Agro-Pink Palette
val KhetPinkPrimary = Color(0xFFE2136E)
val KhetPinkDark = Color(0xFFC20F5D)
val KhetPinkLight = Color(0xFFFDE8F1)
val KhetPinkTint = Color(0xFFFDE8F1)

// 2. Neutral Backgrounds & Canvas Surfaces
val SurfaceWhite = Color(0xFFFFFFFF)
val CanvasBackground = Color(0xFFF5F6F8)

// 3. Typography & Feedback Tokens
val TextPrimary = Color(0xFF212121)
val TextMuted = Color(0xFF6B7280)
val AlertRed = Color(0xFFD32F2F)

// 4. Recommendation Pastel Cards Palette
val PastelAmber = Color(0xFFFFF8E1)
val PastelAmberBorder = Color(0xFFFFE082)
val PastelAmberText = Color(0xFFF57F17)

val PastelGreen = Color(0xFFE8F5E9)
val PastelGreenBorder = Color(0xFFA5D6A7)
val PastelGreenText = Color(0xFF2E7D32)

val PastelBlue = Color(0xFFE3F2FD)
val PastelBlueBorder = Color(0xFF90CAF9)
val PastelBlueText = Color(0xFF1565C0)

private val LightColorScheme = lightColorScheme(
    primary = KhetPinkPrimary,
    onPrimary = SurfaceWhite,
    primaryContainer = KhetPinkTint,
    onPrimaryContainer = KhetPinkDark,
    secondary = KhetPinkDark,
    onSecondary = SurfaceWhite,
    background = CanvasBackground,
    surface = SurfaceWhite,
    onSurface = TextPrimary,
    surfaceVariant = CanvasBackground,
    onSurfaceVariant = TextMuted,
    error = AlertRed,
    onError = SurfaceWhite
)

private val DarkColorScheme = darkColorScheme(
    primary = KhetPinkPrimary,
    onPrimary = SurfaceWhite,
    primaryContainer = KhetPinkDark,
    onPrimaryContainer = KhetPinkTint,
    secondary = KhetPinkLight,
    background = Color(0xFF070D1F),
    surface = Color(0xFF0B132B),
    onSurface = SurfaceWhite,
    error = AlertRed
)

val KhetDrishtiShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp)
)

val KhetDrishtiTypography = Typography(
    titleLarge = TextStyle(
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 26.sp,
        color = TextPrimary
    ),
    titleMedium = TextStyle(
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        lineHeight = 22.sp,
        color = TextPrimary
    ),
    bodyMedium = TextStyle(
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        color = TextPrimary
    ),
    labelSmall = TextStyle(
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        lineHeight = 15.sp,
        color = TextMuted
    )
)

@Composable
fun KhetDrishtiTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        shapes = KhetDrishtiShapes,
        typography = KhetDrishtiTypography,
        content = content
    )
}