package com.khetdrishti.app.data.remote.api

import com.google.gson.annotations.SerializedName
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

/**
 * NASA POWER API (Prediction of Worldwide Energy Resources)
 * Agroclimatology (AG) Community Endpoint
 * Base URL: https://power.larc.nasa.gov/api/
 */
interface NasaPowerApiService {

    @GET("temporal/daily/point")
    suspend fun getDailyAgroclimatology(
        @Query("parameters") parameters: String = "T2M,T2M_MAX,T2M_MIN,PRECTOTCORR,RH2M,ALLSKY_SFC_SW_DWN,WS10M",
        @Query("community") community: String = "AG",
        @Query("longitude") longitude: Double,
        @Query("latitude") latitude: Double,
        @Query("start") startDate: String, // Format: YYYYMMDD
        @Query("end") endDate: String,     // Format: YYYYMMDD
        @Query("format") format: String = "JSON"
    ): Response<NasaPowerResponseDto>
}

data class NasaPowerResponseDto(
    @SerializedName("type") val type: String?,
    @SerializedName("geometry") val geometry: GeometryDto?,
    @SerializedName("properties") val properties: PowerPropertiesDto?,
    @SerializedName("messages") val messages: List<String>?
)

data class GeometryDto(
    @SerializedName("type") val type: String?,
    @SerializedName("coordinates") val coordinates: List<Double>?
)

data class PowerPropertiesDto(
    @SerializedName("parameter") val parameter: ParameterMapDto?
)

data class ParameterMapDto(
    @SerializedName("T2M") val temperatureAvg: Map<String, Double>?,            // Air Temp at 2m (°C)
    @SerializedName("T2M_MAX") val temperatureMax: Map<String, Double>?,        // Max Daily Temp (°C)
    @SerializedName("T2M_MIN") val temperatureMin: Map<String, Double>?,        // Min Daily Temp (°C)
    @SerializedName("PRECTOTCORR") val precipitationMm: Map<String, Double>?,  // Corrected Total Precipitation (mm/day)
    @SerializedName("RH2M") val relativeHumidity: Map<String, Double>?,         // Relative Humidity at 2m (%)
    @SerializedName("ALLSKY_SFC_SW_DWN") val solarInsolation: Map<String, Double>?, // All Sky Surface Shortwave Downward Irradiance (MJ/m^2/day)
    @SerializedName("WS10M") val windSpeed10m: Map<String, Double>?            // Wind Speed at 10m (m/s)
)