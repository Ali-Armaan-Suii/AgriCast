package com.khetdrishti.app.worker

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.khetdrishti.app.domain.repository.FieldRepository
import com.khetdrishti.app.domain.repository.NasaRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * WorkManager Background Sync Worker:
 * Runs periodically (every 6 hours) or on constrained network.
 * 1. Checks NASA POWER 7-day forecast & GPM rainfall
 * 2. Checks VIIRS/MODIS FIRMS for fire hotspots <= 5km
 * 3. Checks SMAP soil moisture thresholds
 * 4. Writes AlertEvent to Cloud Firestore, which triggers Cloud Functions SMTP pipeline
 */
@HiltWorker
class NasaSyncWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted workerParams: WorkerParameters,
    private val nasaRepository: NasaRepository,
    private val fieldRepository: FieldRepository
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val userFields = fieldRepository.getAllActiveFields()

            for (field in userFields) {
                // 1. Check for Active Fires within 5km radius via NASA FIRMS
                val fireAlert = nasaRepository.checkFirmsFireHotspots(
                    lat = field.centroid.latitude,
                    lon = field.centroid.longitude,
                    radiusKm = 5.0
                )

                // 2. Fetch Latest Telemetry
                val telemetry = nasaRepository.getLatestNasaTelemetry(field.fieldId)

                // 3. Evaluate Thresholds & Trigger Cloud Event if Critical
                val isFireThreat = fireAlert != null && fireAlert.distanceKm <= 5.0
                val isWaterCritical = telemetry.smapSurfaceMoisture < 0.16

                if (isFireThreat || isWaterCritical) {
                    fieldRepository.recordAlertEvent(
                        fieldId = field.fieldId,
                        alertType = if (isFireThreat) "FIRE_HOTSPOT" else "WATER_STRESS",
                        severity = "CRITICAL",
                        source = if (isFireThreat) "NASA_VIIRS_FIRMS" else "NASA_SMAP_L4",
                        description = if (isFireThreat) {
                            "Fire hotspot detected \${fireAlert?.distanceKm}km away (FRP: \${fireAlert?.fireRadiativePowerMw} MW)"
                        } else {
                            "Volumetric soil moisture dropped to \${(telemetry.smapSurfaceMoisture * 100).toInt()}%"
                        }
                    )
                }
            }

            Result.success()
        } catch (e: Exception) {
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }
}