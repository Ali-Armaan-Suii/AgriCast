# KhetDrishti (ক্ষেতদৃষ্টি) - Android App Codebase & APK Builder

এই প্যাকেজে সম্পূর্ণ KhetDrishti Android Jetpack Compose অ্যাপ সোর্স কোড অন্তর্ভুক্ত রয়েছে।

## APK বিল্ড ও ফোনে ইনস্টল করার সহজ নিয়ম:

### পদ্ধতি ১: Android Studio দিয়ে সরাসরি ইনস্টল
1. এই জিপ ফাইলটি এক্সট্র্যাক্ট (Unzip) করুন।
2. **Android Studio** ওপেন করে `Open Project` সিলেক্ট করুন এবং `khetdrishti-android` ফোল্ডারটি ওপেন করুন।
3. Gradle Sync সম্পন্ন হওয়ার পর আপনার অ্যান্ড্রয়েড ফোন USB ক্যাবল বা WiFi দিয়ে কানেক্ট করুন।
4. সরাসরি উপরে থাকা সবুজ **Run** বাটনে ক্লিক করলেই আপনার ফোনে অ্যাপ ইনস্টল হয়ে যাবে।

### পদ্ধতি ২: টার্মিনাল/কমান্ড লাইন দিয়ে Debug APK বিল্ড
```bash
cd khetdrishti-android
./gradlew assembleDebug
```
বিল্ড শেষ হলে আপনার ফোনে ইনস্টল করার রেডি APK পাওয়া যাবে এখানে:
`app/build/outputs/apk/debug/app-debug.apk`

---
### বৈশিষ্ট্যসমূহ:
- NASA POWER ও FIRMS রিয়েলটাইম স্যাটেলাইট এপিআই
- মাটির আর্দ্রতা (SMAP) ও ইকোস্ট্রেস মনিটরিং
- বাংলা অডিও গাইড ও কালবৈশাখী ঝড়-বৃষ্টি আবহাওয়া সতর্কতা
- বিকাশ-অনুপ্রাণিত উপাদান ও অফলাইন রুম ডাটাবেজ
