package com.khetdrishti.app.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.GeoPoint
import com.google.firebase.firestore.PropertyName
import com.google.firebase.firestore.ServerTimestamp

/**
 * Cloud Firestore Collection: "users/{userId}"
 */
data class UserFirestoreModel(
    @DocumentId val uid: String = "",
    val email: String = "",
    val displayName: String = "",
    val phoneNumber: String? = null,
    val preferredLanguage: String = "hi", // "hi" (Hindi), "pa" (Punjabi), "en" (English)
    val fcmToken: String? = null,
    val smtpNotificationEmail: String? = null,
    val alertThresholds: AlertThresholdsModel = AlertThresholdsModel(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class AlertThresholdsModel(
    val smapMoistureDeficitLimit: Double = 0.18, // Alert if < 18% VWC
    val ecostressCanopyTempStressMaxC: Double = 33.0,
    val firmsFireHotspotRadiusKm: Double = 5.0,
    val enableSmtpDailyDigest: Boolean = true
)

/**
 * Cloud Firestore Collection: "users/{userId}/fields/{fieldId}"
 */
data class FieldFirestoreModel(
    @DocumentId val fieldId: String = "",
    val ownerUid: String = "",
    val fieldName: String = "",
    val cropName: String = "",
    val cropVariety: String = "",
    val sowingDate: String = "", // ISO-8601
    val harvestProjectedDate: String = "",
    val acreage: Double = 0.0,
    val soilType: String = "", // e.g. "Alluvial Silty Loam", "Vertisol"
    val centroid: GeoPoint = GeoPoint(0.0, 0.0),
    val boundaryPolygonGeoPoints: List<GeoPoint> = emptyList(),
    val latestNdvi: Double = 0.0,
    val latestSmapMoisture: Double = 0.0,
    val latestCanopyTempC: Double = 0.0,
    val activeFireAlertCount: Int = 0,
    @ServerTimestamp val lastSyncedAt: Timestamp? = null
)

/**
 * Subcollection: "users/{userId}/fields/{fieldId}/telemetry_logs/{logId}"
 */
data class TelemetryLogFirestoreModel(
    @DocumentId val logId: String = "",
    val recordedAt: Timestamp = Timestamp.now(),
    val smapSurfaceMoisture: Double = 0.0,
    val smapRootZoneMoisture: Double = 0.0,
    val ecostressCanopyTempC: Double = 0.0,
    val ecostressEsi: Double = 0.0,
    val gpmPrecipMm: Double = 0.0,
    val nisarSubsurfacePct: Double = 0.0,
    val nisarDeformationMm: Double = 0.0,
    val isWaterStressDetected: Boolean = false
)

/**
 * Subcollection: "users/{userId}/fields/{fieldId}/alert_events/{alertId}"
 */
data class AlertEventFirestoreModel(
    @DocumentId val alertId: String = "",
    val alertType: String = "", // "FIRE_HOTSPOT", "WATER_STRESS", "HEAT_ANOMALY"
    val severity: String = "",  // "CRITICAL", "WARNING", "ADVISORY"
    val sourceDataset: String = "", // "NASA_VIIRS", "NASA_SMAP", "NASA_ECOSTRESS"
    val description: String = "",
    val isResolved: Boolean = false,
    val smtpEmailSent: Boolean = false,
    val smtpEmailSentAt: Timestamp? = null,
    @ServerTimestamp val timestamp: Timestamp? = null
)