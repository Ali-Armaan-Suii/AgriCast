package com.khetdrishti.app.data.remote.api

import com.google.gson.annotations.SerializedName
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

/**
 * NASA FIRMS API (Fire Information for Resource Management System)
 * Real-time VIIRS 375m & MODIS 1km active fire hotspots
 * Base URL: https://firms.modaps.eosdis.nasa.gov/api/
 */
interface NasaFirmsApiService {

    /**
     * Radial search for active fires within bounding box or radius (km)
     * Sources: VIIRS_SNPP_NRT, VIIRS_NOAA20_NRT, MODIS_NRT
     */
    @GET("area/csv/{map_key}/{source}/{area}/{day_range}")
    suspend fun getActiveFireHotspotsCsv(
        @Path("map_key") apiKey: String,
        @Path("source") source: String = "VIIRS_SNPP_NRT",
        @Path("area") boundingArea: String, // format: "minLon,minLat,maxLon,maxLat"
        @Path("day_range") dayRange: Int = 1
    ): Response<String>

    @GET("country/json/{map_key}/{source}/{country_code}/{day_range}")
    suspend fun getActiveFiresByCountryJson(
        @Path("map_key") apiKey: String,
        @Path("source") source: String = "VIIRS_SNPP_NRT",
        @Path("country_code") countryCode: String = "IND",
        @Path("day_range") dayRange: Int = 1
    ): Response<List<FirmsFireHotspotDto>>
}

data class FirmsFireHotspotDto(
    @SerializedName("latitude") val latitude: Double,
    @SerializedName("longitude") val longitude: Double,
    @SerializedName("bright_ti4") val brightnessTempI4: Double?,    // VIIRS 375m I4 Channel (Kelvin)
    @SerializedName("scan") val scanResolution: Double?,
    @SerializedName("track") val trackResolution: Double?,
    @SerializedName("acq_date") val acquisitionDate: String,        // YYYY-MM-DD
    @SerializedName("acq_time") val acquisitionTime: String,        // HHMM UTC
    @SerializedName("satellite") val satellite: String,             // N: Suomi NPP, 20: NOAA-20, T: Terra, A: Aqua
    @SerializedName("confidence") val confidence: String?,          // "l" (low), "n" (nominal), "h" (high)
    @SerializedName("version") val version: String?,
    @SerializedName("bright_ti5") val brightnessTempI5: Double?,    // Channel I5 (Kelvin)
    @SerializedName("frp") val fireRadiativePowerMw: Double?,       // Fire Radiative Power (MW)
    @SerializedName("daynight") val dayNightFlag: String?           // "D" or "N"
)