package com.khetdrishti.app.di

import com.khetdrishti.app.data.remote.api.NasaFirmsApiService
import com.khetdrishti.app.data.remote.api.NasaPowerApiService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {

    private const val NASA_POWER_BASE_URL = "https://power.larc.nasa.gov/api/"
    private const val NASA_FIRMS_BASE_URL = "https://firms.modaps.eosdis.nasa.gov/api/"

    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            })
            .retryOnConnectionFailure(true)
            .build()
    }

    @Provides
    @Singleton
    @Named("NasaPowerRetrofit")
    fun provideNasaPowerRetrofit(okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(NASA_POWER_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    @Provides
    @Singleton
    @Named("NasaFirmsRetrofit")
    fun provideNasaFirmsRetrofit(okHttpClient: OkHttpClient): Retrofit {
        return Retrofit.Builder()
            .baseUrl(NASA_FIRMS_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    @Provides
    @Singleton
    fun provideNasaPowerApiService(@Named("NasaPowerRetrofit") retrofit: Retrofit): NasaPowerApiService {
        return retrofit.create(NasaPowerApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideNasaFirmsApiService(@Named("NasaFirmsRetrofit") retrofit: Retrofit): NasaFirmsApiService {
        return retrofit.create(NasaFirmsApiService::class.java)
    }
}