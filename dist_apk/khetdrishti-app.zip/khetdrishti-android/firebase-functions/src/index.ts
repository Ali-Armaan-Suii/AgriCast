import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';
import * as nodemailer from 'nodemailer';

admin.initializeApp();
const db = admin.firestore();

// Configure SMTP transport using environment variables or Secret Manager
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.sendgrid.net',
  port: Number(process.env.SMTP_PORT) || 587,
  secure: false, // true for 465, false for other ports
  auth: {
    user: process.env.SMTP_USER || 'apikey',
    pass: process.env.SMTP_PASSWORD || 'SG.your_sendgrid_key_here',
  },
});

/**
 * Cloud Function Trigger: onDocumentCreated in alert_events subcollection
 * Sends an immediate, high-priority email to farmer if severity is CRITICAL or WARNING.
 */
export const onNasaAlertCreated = functions.firestore
  .document('users/{userId}/fields/{fieldId}/alert_events/{alertId}')
  .onCreate(async (snap, context) => {
    const alertData = snap.data();
    const { userId, fieldId } = context.params;

    if (!alertData || alertData.severity !== 'CRITICAL') {
      return null;
    }

    try {
      // 1. Retrieve Farmer User Profile
      const userDoc = await db.collection('users').doc(userId).get();
      const userData = userDoc.data();
      const recipientEmail = userData?.smtpNotificationEmail || userData?.email;

      if (!recipientEmail) {
        console.warn(\`No recipient email registered for user \${userId}\`);
        return null;
      }

      // 2. Retrieve Field Details
      const fieldDoc = await db.collection('users').doc(userId).collection('fields').doc(fieldId).get();
      const fieldData = fieldDoc.data();
      const fieldName = fieldData?.fieldName || 'Plot A';

      // 3. Compose Space-Grade SaaS Alert Email
      const mailOptions = {
        from: '"KhetDrishti NASA Intelligence" <alerts@khetdrishti.nasa.agro>',
        to: recipientEmail,
        subject: \`⚠️ [CRITICAL ALERT] \${alertData.alertType} Detected near \${fieldName}\